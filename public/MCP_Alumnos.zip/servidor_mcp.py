"""Servidor MCP educativo de consulta de alumnos mediante stdio."""

from pathlib import Path
import sqlite3
from typing import Any

from mcp.server.fastmcp import FastMCP


BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "alumnos.db"

mcp = FastMCP(
    "MCP Alumnos",
    instructions="Servidor de solo lectura para consultar alumnos ficticios de Ingeniería en Sistemas.",
)


def _consultar(sql: str, parametros: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
    """Ejecuta una consulta de lectura y convierte sus filas en diccionarios."""
    if not DB_PATH.exists():
        raise RuntimeError(
            f"No existe la base de datos en {DB_PATH}. Ejecuta primero crear_bd.py."
        )
    try:
        with sqlite3.connect(DB_PATH) as conexion:
            conexion.row_factory = sqlite3.Row
            filas = conexion.execute(sql, parametros).fetchall()
            return [dict(fila) for fila in filas]
    except sqlite3.Error as error:
        raise RuntimeError(f"No se pudo consultar SQLite: {error}") from error


@mcp.tool()
def listar_alumnos() -> list[dict[str, Any]]:
    """Utilízala para obtener todos los alumnos registrados en la base de datos."""
    return _consultar(
        "SELECT id, nombre, semestre, promedio FROM alumnos ORDER BY id"
    )


@mcp.tool()
def obtener_reprobados() -> list[dict[str, Any]]:
    """Utilízala para identificar alumnos con promedio inferior a 70."""
    return _consultar(
        "SELECT id, nombre, semestre, promedio FROM alumnos "
        "WHERE promedio < ? ORDER BY promedio, id",
        (70,),
    )


@mcp.tool()
def promedio_grupo() -> dict[str, float | int]:
    """Utilízala para calcular el promedio general de todos los alumnos."""
    filas = _consultar("SELECT COUNT(*) AS cantidad, AVG(promedio) AS promedio FROM alumnos")
    if not filas or filas[0]["cantidad"] == 0:
        raise RuntimeError("La tabla alumnos está vacía; no se puede calcular el promedio.")
    return {
        "cantidad_alumnos": int(filas[0]["cantidad"]),
        "promedio_general": round(float(filas[0]["promedio"]), 2),
    }


@mcp.tool()
def buscar_alumno(nombre: str) -> list[dict[str, Any]]:
    """Utilízala para buscar por nombre ignorando mayúsculas y minúsculas."""
    if not isinstance(nombre, str) or not nombre.strip():
        raise ValueError("El nombre debe ser una cadena no vacía.")
    return _consultar(
        "SELECT id, nombre, semestre, promedio FROM alumnos "
        "WHERE nombre LIKE ? COLLATE NOCASE ORDER BY id",
        (f"%{nombre.strip()}%",),
    )


@mcp.tool()
def alumnos_por_semestre(semestre: int) -> list[dict[str, Any]]:
    """Utilízala para consultar los alumnos inscritos en un semestre concreto."""
    if semestre not in (6, 7, 8):
        raise ValueError("El semestre debe ser 6, 7 u 8.")
    return _consultar(
        "SELECT id, nombre, semestre, promedio FROM alumnos "
        "WHERE semestre = ? ORDER BY id",
        (semestre,),
    )


if __name__ == "__main__":
    mcp.run(transport="stdio")
