"""Crea de forma reproducible la base de datos académica de la práctica."""

from pathlib import Path
import sqlite3


BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "alumnos.db"

ALUMNOS = [
    (1, "Ana López", 6, 68.0),
    (2, "Bruno García", 6, 88.0),
    (3, "Carla Méndez", 6, 91.0),
    (4, "Diego Torres", 6, 59.0),
    (5, "Elena Ruiz", 7, 65.0),
    (6, "Fabián Cruz", 7, 72.0),
    (7, "Gabriela Soto", 7, 76.0),
    (8, "Hugo Nava", 8, 84.0),
    (9, "Irene Vega", 8, 67.0),
    (10, "Jorge León", 8, 95.0),
]


def crear_base_de_datos() -> None:
    """Crea la tabla y vuelve a insertar el conjunto didáctico conocido."""
    with sqlite3.connect(DB_PATH) as conexion:
        conexion.execute("DROP TABLE IF EXISTS alumnos")
        conexion.execute(
            """
            CREATE TABLE alumnos (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                semestre INTEGER NOT NULL CHECK (semestre IN (6, 7, 8)),
                promedio REAL NOT NULL CHECK (promedio >= 0 AND promedio <= 100)
            )
            """
        )
        conexion.executemany(
            "INSERT INTO alumnos (id, nombre, semestre, promedio) VALUES (?, ?, ?, ?)",
            ALUMNOS,
        )
        conexion.commit()


if __name__ == "__main__":
    crear_base_de_datos()
    print(f"Base de datos creada en: {DB_PATH}")
