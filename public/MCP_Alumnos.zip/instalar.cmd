@echo off
setlocal
chcp 65001 >nul
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
echo El instalador termin? con c?digo %EXIT_CODE%.
pause
exit /b %EXIT_CODE%
