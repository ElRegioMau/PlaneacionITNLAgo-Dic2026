"""Prueba el servidor completo usando el cliente MCP real sobre stdio."""

import asyncio
import json
from pathlib import Path
import sqlite3
import sys

from mcp.client.session import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client


BASE_DIR = Path(__file__).resolve().parent
SERVER_PATH = BASE_DIR / "servidor_mcp.py"
DB_PATH = BASE_DIR / "alumnos.db"
HERRAMIENTAS_ESPERADAS = {
    "listar_alumnos",
    "obtener_reprobados",
    "promedio_grupo",
    "buscar_alumno",
    "alumnos_por_semestre",
}


def leer_expectativas_sqlite() -> tuple[int, float]:
    with sqlite3.connect(DB_PATH) as conexion:
        reprobados = conexion.execute(
            "SELECT COUNT(*) FROM alumnos WHERE promedio < 70"
        ).fetchone()[0]
        promedio = conexion.execute("SELECT AVG(promedio) FROM alumnos").fetchone()[0]
    return int(reprobados), round(float(promedio), 2)


def convertir_resultado(resultado) -> object:
    """Obtiene el contenido estructurado o JSON que devuelve FastMCP v1."""
    estructurado = getattr(resultado, "structured_content", None)
    if estructurado is None:
        estructurado = getattr(resultado, "structuredContent", None)
    if estructurado:
        return estructurado.get("result", estructurado)
    for contenido in getattr(resultado, "content", []):
        texto = getattr(contenido, "text", None)
        if texto:
            return json.loads(texto)
    raise AssertionError("La respuesta MCP no contiene contenido interpretable.")


async def main() -> None:
    reprobados_esperados, promedio_esperado = leer_expectativas_sqlite()
    parametros = StdioServerParameters(
        command=sys.executable,
        args=[str(SERVER_PATH)],
        cwd=str(BASE_DIR),
    )

    async with stdio_client(parametros) as (lectura, escritura):
        async with ClientSession(lectura, escritura) as sesion:
            await sesion.initialize()
            listado = await sesion.list_tools()
            nombres = {herramienta.name for herramienta in listado.tools}
            assert nombres == HERRAMIENTAS_ESPERADAS, nombres

            resultado_reprobados = convertir_resultado(
                await sesion.call_tool("obtener_reprobados", {})
            )
            assert isinstance(resultado_reprobados, list)
            assert len(resultado_reprobados) == reprobados_esperados
            assert all(alumno["promedio"] < 70 for alumno in resultado_reprobados)

            resultado_promedio = convertir_resultado(
                await sesion.call_tool("promedio_grupo", {})
            )
            assert resultado_promedio["cantidad_alumnos"] == 10
            assert resultado_promedio["promedio_general"] == promedio_esperado

    print("OK: el servidor inició mediante stdio.")
    print(f"OK: se descubrieron 5 herramientas: {sorted(nombres)}")
    print(f"OK: obtener_reprobados() coincide con SQLite ({reprobados_esperados} alumnos).")
    print(f"OK: promedio_grupo() coincide con SQLite ({promedio_esperado}).")
    print("Todas las pruebas MCP finalizaron correctamente.")


if __name__ == "__main__":
    asyncio.run(main())
