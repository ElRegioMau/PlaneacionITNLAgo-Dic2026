# Práctica portátil: servidor MCP de alumnos

Esta práctica muestra cómo un agente compatible con MCP puede descubrir y ejecutar herramientas que consultan una base de datos local. El servidor es de solo lectura: ningún agente puede insertar, modificar o eliminar alumnos mediante MCP.

## Arquitectura

```text
MCP_Alumnos/
├── instalar.cmd          # Instalador para doble clic en Windows
├── instalar.ps1          # Instalador principal, basado en su propia carpeta
├── .vscode/mcp.json      # Configuración local para VS Code/Copilot
├── alumnos.db            # SQLite generado si todavía no existe
├── crear_bd.py           # Crea datos ficticios reproducibles
├── servidor_mcp.py       # FastMCP y cinco herramientas de lectura
├── probar_mcp.py         # Cliente MCP real sobre stdio
├── requirements.txt      # SDK oficial MCP, línea FastMCP v1
├── .gitignore
└── README.md
```

MCP es un protocolo estandarizado para que una aplicación de IA descubra y utilice herramientas, recursos y datos ofrecidos por un servidor. Aquí el agente no necesita conocer la implementación interna de SQLite: descubre cinco herramientas con nombres, tipos y descripciones, y las invoca mediante `stdio`.

## Guía de instalación para estudiantes

### 1. Requisitos previos

- Windows 10 u 11.
- Python 3.11 o superior. El instalador prefiere Python 3.11 o 3.12 si están disponibles y usa el lanzador `py` cuando existe.
- Conexión a Internet durante la primera instalación para descargar el SDK MCP.
- Un cliente opcional: Codex, Claude Code o VS Code con GitHub Copilot.

No es necesario instalar todos los agentes. Puedes elegir solamente el que tengas disponible.

### 2. Descargar el proyecto

Descarga el repositorio o la carpeta `MCP_Alumnos` y descomprímela, por ejemplo, en cualquiera de estas rutas:

```text
C:\Users\Alumno\Desktop\MCP_Alumnos
D:\Universidad\Programacion\MCP_Alumnos
C:\Users\Juan Perez\Documents\MCP_Alumnos
```

Los espacios, acentos y el nombre de usuario no afectan al instalador.

### 3. Ejecutar `instalar.cmd`

Abre la carpeta y haz doble clic en `instalar.cmd`. El instalador:

1. Detecta su propia ubicación mediante `$PSScriptRoot`.
2. Busca Python 3.11 o superior y comprueba que el entorno pueda instalar las dependencias.
3. Crea `.venv` solamente si no existe.
4. Instala `requirements.txt` dentro de `.venv`.
5. Crea `alumnos.db` solamente si no existe; nunca borra datos durante la instalación.
6. Ejecuta el cliente MCP real y verifica las cinco herramientas.
7. Muestra un menú para configurar un agente.

También puedes ejecutarlo desde PowerShell sin cambiar primero el directorio:

```powershell
& "D:\Universidad\Programacion\MCP_Alumnos\instalar.cmd"
```

El instalador conserva la ventana abierta al terminar.

### 4. Elegir un agente

Después de la prueba aparecerá este menú:

```text
1. Configurar Codex
2. Configurar Claude Code
3. Configurar GitHub Copilot
4. Solo instalar y probar MCP
5. Salir
```

#### Codex

La opción 1 comprueba si ya existe la sección `[mcp_servers.alumnos-mcp]` en `%USERPROFILE%\.codex\config.toml`. Si no existe, solicita confirmación antes de modificarla y crea un respaldo con fecha. No usa ni exige el comando `codex` en PATH y no agrega secciones TOML duplicadas.

Después de aceptar, reinicia la extensión de Codex y revisa que el servidor aparezca con sus herramientas. El instalador no declara probada la integración de Codex porque depende de que la extensión esté instalada y conectada en la computadora del alumno.

#### Claude Code

La opción 2 comprueba el comando `claude`. Si está disponible, ejecuta el registro mediante transporte `stdio` y muestra el resultado. Si no está disponible, solo muestra instrucciones y no produce un error falso.

Claude Code es diferente de Claude Desktop y del chat web de Claude. Para verificar un registro exitoso:

```powershell
claude mcp list
```

La integración solamente se considera probada si Claude Code está instalado y el propio comando confirma el registro.

#### GitHub Copilot

La opción 3 crea o verifica `.vscode/mcp.json` usando rutas portátiles:

```json
{
  "servers": {
    "alumnos-mcp": {
      "type": "stdio",
      "command": "${workspaceFolder}\\.venv\\Scripts\\python.exe",
      "args": ["${workspaceFolder}\\servidor_mcp.py"]
    }
  }
}
```

En VS Code, abre como carpeta la carpeta `MCP_Alumnos`, no `Unidad4` ni una carpeta padre. Abre Copilot Chat en modo **Agent**, revisa el selector de herramientas, habilita `alumnos-mcp` y realiza una pregunta que necesite consultar alumnos.

### 5. Comprobar que MCP está conectado

La instalación comprueba el protocolo por sí misma con:

```powershell
.\.venv\Scripts\python.exe .\probar_mcp.py
```

La salida debe indicar que el servidor inició mediante `stdio`, que se descubrieron cinco herramientas y que las respuestas coinciden con SQLite. Eso prueba el servidor y el cliente MCP local, aunque todavía no prueba la interfaz de un agente concreto.

### 6. Tres preguntas de prueba

<details>
<summary>Mostrar preguntas</summary>

1. ¿Qué alumnos tienen promedio menor que 70?
2. ¿Cuál es el promedio general del grupo?
3. ¿Qué alumnos están inscritos en el semestre 8?

</details>

### 7. Comprobar llamadas reales a herramientas

Observa el registro de la conversación del agente. Debe aparecer una llamada MCP como `obtener_reprobados`, `promedio_grupo` o `alumnos_por_semestre`. El resultado debe corresponder con `alumnos.db`.

La prueba `probar_mcp.py` también es una comprobación real: inicia `servidor_mcp.py` como proceso separado, negocia MCP por `stdio`, lista herramientas y ejecuta dos herramientas. No llama directamente a las funciones Python del servidor.

### 8. Errores comunes

<details>
<summary>Mostrar soluciones</summary>

- **“No se encontró Python 3.11 o superior”**: instala Python desde python.org y activa la opción de agregar el lanzador `py` al sistema.
- **La instalación de dependencias falla**: comprueba Internet y vuelve a ejecutar `instalar.cmd`. Si `.venv` quedó incompleto, elimínalo manualmente y repite; el instalador nunca elimina un entorno existente por su cuenta.
- **Copilot no muestra el servidor**: abre exactamente la carpeta `MCP_Alumnos`, reinicia VS Code y revisa `.vscode/mcp.json`.
- **Codex no aparece configurado**: reinicia la extensión y revisa `%USERPROFILE%\.codex\config.toml`; el instalador solo modifica ese archivo después de confirmación.
- **Claude Code no está disponible**: la opción del instalador no configura Claude Desktop ni el chat web. Instala Claude Code y vuelve a ejecutar la opción correspondiente.
- **La ventana se cierra demasiado pronto**: ejecuta `instalar.cmd` con doble clic; el archivo incluye una pausa final.

</details>

## Ejecutar manualmente

Si no deseas usar el instalador:

```powershell
cd "C:\ruta\a\MCP_Alumnos"
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
if (-not (Test-Path .\alumnos.db)) { .\.venv\Scripts\python.exe .\crear_bd.py }
.\.venv\Scripts\python.exe .\probar_mcp.py
```

`crear_bd.py` reconstruye intencionalmente el conjunto didáctico cuando se ejecuta de forma manual. El instalador no lo vuelve a ejecutar si `alumnos.db` ya existe.

## Herramientas disponibles

- `listar_alumnos()`: devuelve todos los alumnos.
- `obtener_reprobados()`: devuelve promedios menores de 70.
- `promedio_grupo()`: devuelve cantidad y promedio general.
- `buscar_alumno(nombre)`: busca sin distinguir mayúsculas y minúsculas.
- `alumnos_por_semestre(semestre)`: filtra por 6, 7 u 8.

Todas usan la ruta derivada de `__file__`, consultas parametrizadas cuando reciben parámetros y manejo de errores. La línea `mcp[cli]>=1.28,<2` conserva `FastMCP`; la línea v2 del SDK renombró esa clase a `MCPServer`.
