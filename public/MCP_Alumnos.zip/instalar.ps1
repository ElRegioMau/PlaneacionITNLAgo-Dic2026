Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$ProjectRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$Requirements = Join-Path $ProjectRoot "requirements.txt"
$Database = Join-Path $ProjectRoot "alumnos.db"
$CreateDatabase = Join-Path $ProjectRoot "crear_bd.py"
$TestMcp = Join-Path $ProjectRoot "probar_mcp.py"
$Server = Join-Path $ProjectRoot "servidor_mcp.py"
$VenvRoot = Join-Path $ProjectRoot ".venv"
$VenvPython = Join-Path $VenvRoot "Scripts\python.exe"
$CopilotConfig = Join-Path $ProjectRoot ".vscode\mcp.json"

function Write-Info([string]$Message) {
    Write-Host "[INFO] $Message" -ForegroundColor Cyan
}

function Write-Ok([string]$Message) {
    Write-Host "[OK]   $Message" -ForegroundColor Green
}

function Write-Warn([string]$Message) {
    Write-Host "[AVISO] $Message" -ForegroundColor Yellow
}

function Stop-Installer([string]$Message) {
    Write-Host "[ERROR] $Message" -ForegroundColor Red
    Read-Host "Presiona Enter para cerrar"
    exit 1
}

function Get-PythonVersion {
    param(
        [Parameter(Mandatory = $true)][string]$Command,
        [string[]]$PrefixArguments = @()
    )

    try {
        $output = (& $Command @PrefixArguments --version 2>&1 | Out-String).Trim()
        if ($LASTEXITCODE -ne 0) {
            return $null
        }
        $match = [regex]::Match($output, "Python\s+(\d+)\.(\d+)\.(\d+)")
        if (-not $match.Success) {
            return $null
        }
        return [version]::new(
            [int]$match.Groups[1].Value,
            [int]$match.Groups[2].Value,
            [int]$match.Groups[3].Value
        )
    }
    catch {
        return $null
    }
}

function Get-PythonCandidates {
    $candidates = New-Object System.Collections.Generic.List[object]

    if (Get-Command py -ErrorAction SilentlyContinue) {
        # Se prefieren 3.11 y 3.12 porque son versiones ampliamente compatibles.
        foreach ($minor in @(11, 12, 13, 14, 15)) {
            $arguments = @("-3.$minor")
            $version = Get-PythonVersion -Command "py" -PrefixArguments $arguments
            if ($null -ne $version -and $version -ge [version]::new(3, 11, 0)) {
                $candidates.Add([pscustomobject]@{
                        Command = "py"
                        PrefixArguments = $arguments
                        Version = $version
                    })
            }
        }
    }

    foreach ($command in @("python", "python3")) {
        if (Get-Command $command -ErrorAction SilentlyContinue) {
            $version = Get-PythonVersion -Command $command -PrefixArguments @()
            if ($null -ne $version -and $version -ge [version]::new(3, 11, 0)) {
                $candidates.Add([pscustomobject]@{
                        Command = $command
                        PrefixArguments = @()
                        Version = $version
                    })
            }
        }
    }

    return $candidates
}

function Invoke-CheckedPython {
    param(
        [Parameter(Mandatory = $true)][string]$Python,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$FailureMessage
    )

    & $Python @Arguments
    if ($LASTEXITCODE -ne 0) {
        Stop-Installer $FailureMessage
    }
}

function Ensure-PythonAndVenv {
    if (-not (Test-Path -LiteralPath $Requirements)) {
        Stop-Installer "No se encontró requirements.txt en $ProjectRoot."
    }

    if (Test-Path -LiteralPath $VenvPython) {
        $venvVersion = Get-PythonVersion -Command $VenvPython -PrefixArguments @()
        if ($null -eq $venvVersion -or $venvVersion -lt [version]::new(3, 11, 0)) {
            Stop-Installer "El entorno .venv existente no usa Python 3.11 o superior. No se borró; revisa o renueva .venv manualmente."
        }
        Write-Ok "Entorno virtual existente: Python $venvVersion"
        return
    }

    $candidates = @(Get-PythonCandidates)
    if ($candidates.Count -eq 0) {
        Stop-Installer "No se encontró Python 3.11 o superior. Instala Python desde python.org y habilita el lanzador py."
    }

    $selected = $candidates[0]
    Write-Info "Python seleccionado: $($selected.Version) mediante $($selected.Command) $($selected.PrefixArguments -join ' ')"
    & $selected.Command @($selected.PrefixArguments) -m venv $VenvRoot
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $VenvPython)) {
        Stop-Installer "No se pudo crear el entorno virtual."
    }
    Write-Ok "Entorno virtual creado en $VenvRoot"
}

function Install-Dependencies {
    Write-Info "Instalando dependencias y comprobando compatibilidad de Python..."
    Invoke-CheckedPython -Python $VenvPython -Arguments @("-m", "pip", "install", "-r", $Requirements) -FailureMessage "La instalación de dependencias falló. Revisa la conexión a Internet y la versión de Python."
    Write-Ok "Dependencias instaladas correctamente."
}

function Ensure-Database {
    if (Test-Path -LiteralPath $Database) {
        Write-Ok "alumnos.db ya existe; no se modificaron sus datos."
        return
    }
    Write-Info "alumnos.db no existe; creando la base de datos inicial..."
    Invoke-CheckedPython -Python $VenvPython -Arguments @($CreateDatabase) -FailureMessage "No se pudo crear alumnos.db."
    Write-Ok "Base de datos creada."
}

function Test-McpServer {
    Write-Info "Ejecutando la prueba real del cliente MCP por stdio..."
    Invoke-CheckedPython -Python $VenvPython -Arguments @($TestMcp) -FailureMessage "La prueba MCP falló. Revisa el mensaje anterior."
    Write-Ok "Servidor MCP comprobado: cinco herramientas descubiertas y respuestas verificadas contra SQLite."
}

function Ensure-CopilotConfig {
    $configDirectory = Split-Path -Parent $CopilotConfig
    if (-not (Test-Path -LiteralPath $configDirectory)) {
        New-Item -ItemType Directory -Path $configDirectory -Force | Out-Null
    }

    $config = $null
    if (Test-Path -LiteralPath $CopilotConfig) {
        try {
            $config = Get-Content -Raw -LiteralPath $CopilotConfig | ConvertFrom-Json
        }
        catch {
            Write-Warn "El archivo .vscode/mcp.json no es JSON válido. No se sobrescribirá automáticamente."
            Write-Host "Corrígelo o respáldalo manualmente y vuelve a ejecutar el instalador."
            return
        }
    }

    if ($null -eq $config) {
        $config = [pscustomobject]@{ servers = [pscustomobject]@{} }
    }
    if ($null -eq $config.servers) {
        $config | Add-Member -MemberType NoteProperty -Name servers -Value ([pscustomobject]@{})
    }

    $serverEntry = [pscustomobject]@{
        type = "stdio"
        command = '${workspaceFolder}\.venv\Scripts\python.exe'
        args = @('${workspaceFolder}\servidor_mcp.py')
    }
    $existing = $config.servers.PSObject.Properties["alumnos-mcp"]
    if ($null -eq $existing) {
        $config.servers | Add-Member -MemberType NoteProperty -Name "alumnos-mcp" -Value $serverEntry
        $config | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $CopilotConfig -Encoding UTF8
        Write-Ok "Configuración de GitHub Copilot creada/verificada en .vscode\mcp.json"
    }
    else {
        Write-Ok "Configuración de GitHub Copilot ya contiene el servidor alumnos-mcp."
    }
}

function ConvertTo-TomlString([string]$Value) {
    return '"' + ($Value.Replace('\', '\\').Replace('"', '\"')) + '"'
}

function Configure-Codex {
    $codexDirectory = Join-Path $HOME ".codex"
    $codexConfig = Join-Path $codexDirectory "config.toml"
    $header = "[mcp_servers.alumnos-mcp]"

    if ((Test-Path -LiteralPath $codexConfig) -and ((Get-Content -Raw -LiteralPath $codexConfig) -match '(?m)^\[mcp_servers\.alumnos-mcp\]\s*$')) {
        Write-Ok "Codex ya contiene la sección $header; no se agregó una sección duplicada."
        return
    }

    Write-Host "Esta opción modificará la configuración de usuario: $codexConfig" -ForegroundColor Yellow
    $confirmation = Read-Host "¿Deseas agregar alumnos-mcp a Codex? (S/N)"
    if ($confirmation -notmatch '^(s|si|sí|y|yes)$') {
        Write-Info "No se modificó la configuración de Codex."
        return
    }

    if (-not (Test-Path -LiteralPath $codexDirectory)) {
        New-Item -ItemType Directory -Path $codexDirectory -Force | Out-Null
    }
    if (Test-Path -LiteralPath $codexConfig) {
        $backup = "$codexConfig.bak-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        Copy-Item -LiteralPath $codexConfig -Destination $backup
        Write-Info "Respaldo creado: $backup"
    }

    $toml = @(
        "",
        $header,
        "command = $(ConvertTo-TomlString $VenvPython)",
        "args = [$(ConvertTo-TomlString $Server)]",
        "cwd = $(ConvertTo-TomlString $ProjectRoot)",
        ""
    ) -join [Environment]::NewLine
    Add-Content -LiteralPath $codexConfig -Value $toml -Encoding UTF8
    Write-Ok "Servidor alumnos-mcp agregado a Codex. Reinicia la extensión y verifica sus herramientas."
}

function Configure-ClaudeCode {
    $claude = Get-Command claude -ErrorAction SilentlyContinue
    if ($null -eq $claude) {
        Write-Warn "Claude Code no está disponible en PATH. No se modificó nada."
        Write-Host "Claude Code es distinto de Claude Desktop y del chat web de Claude."
        Write-Host "Si lo instalas, vuelve a ejecutar el instalador o usa:"
        Write-Host "claude mcp add --transport stdio alumnos-mcp -- `"$VenvPython`" `"$Server`""
        return
    }

    Write-Info "Claude Code detectado. Registrando alumnos-mcp mediante stdio..."
    & $claude.Source mcp add --transport stdio alumnos-mcp -- $VenvPython $Server
    if ($LASTEXITCODE -ne 0) {
        Write-Warn "Claude Code rechazó el registro. No se afirmará que quedó configurado."
        return
    }
    Write-Ok "Claude Code registró alumnos-mcp. Compruébalo con: claude mcp list"
}

function Show-Menu {
    while ($true) {
        Write-Host ""
        Write-Host "===== Selecciona tu agente =====" -ForegroundColor Magenta
        Write-Host "1. Configurar Codex"
        Write-Host "2. Configurar Claude Code"
        Write-Host "3. Configurar GitHub Copilot"
        Write-Host "4. Solo instalar y probar MCP"
        Write-Host "5. Salir"
        $choice = Read-Host "Opción"
        switch ($choice) {
            "1" { Configure-Codex }
            "2" { Configure-ClaudeCode }
            "3" { Ensure-CopilotConfig }
            "4" { Write-Ok "MCP queda instalado y probado; no se configuró ningún agente."; return }
            "5" { Write-Info "Sin cambios adicionales."; return }
            default { Write-Warn "Selecciona una opción del 1 al 5." }
        }
    }
}

Write-Host "==============================================" -ForegroundColor Magenta
Write-Host " Instalador portátil - MCP Alumnos" -ForegroundColor Magenta
Write-Host "==============================================" -ForegroundColor Magenta
Write-Info "Carpeta detectada: $ProjectRoot"

try {
    Ensure-PythonAndVenv
    Install-Dependencies
    Ensure-Database
    Test-McpServer
    Show-Menu
    Write-Host ""
    Write-Ok "Instalación finalizada."
    Read-Host "Presiona Enter para cerrar"
}
catch {
    Stop-Installer $_.Exception.Message
}
