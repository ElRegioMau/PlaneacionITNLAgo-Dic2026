from pathlib import Path
import pygame
from colisiones import mover_con_colisiones

CARPETA_SPRITES = Path(__file__).resolve().parent / "assets" / "player"
ESTADOS = ("idle", "run", "jump", "fall")
TAMANO_SPRITE = (96, 96)
VELOCIDAD_ANIMACION = 0.15  # Cuadros por actualización, a 60 FPS.


def cargar_animaciones():
    """Carga archivos PNG individuales ordenados por nombre para cada estado."""
    animaciones = {}
    for estado in ESTADOS:
        archivos = sorted((CARPETA_SPRITES / estado).glob("*.png"))
        animaciones[estado] = [
            pygame.transform.scale(
                pygame.image.load(str(ruta)).convert_alpha(), TAMANO_SPRITE
            )
            for ruta in archivos
        ]
    return animaciones


class Player:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, 40, 55)
        self.x, self.y = float(x), float(y)
        self.velocidad_x = 0
        self.velocidad_y = 0
        self.velocidad_movimiento = 5
        self.fuerza_salto = -13
        self.gravedad = 0.6
        self.velocidad_caida_maxima = 14
        self.en_suelo = False
        self.mira_derecha = True
        self.animaciones = cargar_animaciones()
        self.estado = "idle"
        self.cuadro = 0.0

    def saltar(self):
        if self.en_suelo:
            self.velocidad_y = self.fuerza_salto
            self.en_suelo = False

    def actualizar(self, teclas, plataformas, ancho_pantalla):
        self.velocidad_x = 0
        if teclas[pygame.K_LEFT] or teclas[pygame.K_a]:
            self.velocidad_x = -self.velocidad_movimiento
            self.mira_derecha = False
        if teclas[pygame.K_RIGHT] or teclas[pygame.K_d]:
            self.velocidad_x = self.velocidad_movimiento
            self.mira_derecha = True

        self.velocidad_y = min(self.velocidad_y + self.gravedad, self.velocidad_caida_maxima)
        mover_con_colisiones(self, plataformas)
        self.rect.clamp_ip(pygame.Rect(0, -1000, ancho_pantalla, 3000))
        self.x = float(self.rect.x)

        if not self.en_suelo:
            estado = "jump" if self.velocidad_y < 0 else "fall"
        elif self.velocidad_x:
            estado = "run"
        else:
            estado = "idle"
        if estado != self.estado:
            self.estado = estado
            self.cuadro = 0.0
        cuadros = self.animaciones[self.estado]
        if cuadros:
            self.cuadro = (self.cuadro + VELOCIDAD_ANIMACION) % len(cuadros)

    def dibujar(self, pantalla):
        cuadros = self.animaciones[self.estado]
        if not cuadros:
            pygame.draw.rect(pantalla, (255, 190, 70), self.rect, border_radius=6)
            return
        imagen = cuadros[int(self.cuadro)]
        if not self.mira_derecha:
            imagen = pygame.transform.flip(imagen, True, False)
        # La imagen se alinea con los pies de la caja de colisión.
        posicion = imagen.get_rect(midbottom=self.rect.midbottom)
        # Un contorno claro discreto mejora la lectura sobre el fondo nocturno.
        mascara = pygame.mask.from_surface(imagen)
        contorno = mascara.to_surface(setcolor=(207, 192, 161, 210), unsetcolor=(0, 0, 0, 0))
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            pantalla.blit(contorno, posicion.move(dx, dy))
        pantalla.blit(imagen, posicion)
