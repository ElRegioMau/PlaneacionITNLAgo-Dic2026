import sys
import pygame
from nivel import crear_plataformas
from player import Player
from plataformas import DibujadorPlataformas

ANCHO, ALTO = 960, 640
FPS = 60
COLOR_FONDO = (30, 36, 56)
COLOR_PLATAFORMA = (100, 190, 120)


def cargar_fondo():
    """Carga assets/fondo.png si existe; de lo contrario usa un color."""
    from pathlib import Path
    ruta = Path(__file__).resolve().parent / "assets" / "fondo.png"
    if ruta.is_file():
        imagen = pygame.image.load(str(ruta)).convert()
        return pygame.transform.smoothscale(imagen, (ANCHO, ALTO))
    return None


def main():
    pygame.init()
    pantalla = pygame.display.set_mode((ANCHO, ALTO))
    pygame.display.set_caption("Mi primer plataformero")
    reloj = pygame.time.Clock()
    fondo = cargar_fondo()
    plataformas = crear_plataformas()
    jugador = Player(80, 450)
    dibujador = DibujadorPlataformas()

    while True:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if evento.type == pygame.KEYDOWN:
                if evento.key in (pygame.K_SPACE, pygame.K_UP, pygame.K_w):
                    jugador.saltar()

        jugador.actualizar(pygame.key.get_pressed(), plataformas, ANCHO)
        if fondo is None:
            pantalla.fill(COLOR_FONDO)
        else:
            pantalla.blit(fondo, (0, 0))
        dibujador.dibujar(pantalla, plataformas)
        jugador.dibujar(pantalla)
        pygame.display.flip()
        reloj.tick(FPS)


if __name__ == "__main__":
    main()
