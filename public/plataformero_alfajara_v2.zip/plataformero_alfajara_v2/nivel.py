import pygame


def crear_plataformas():
    # Cada rectángulo se define como: x, y, ancho, alto.
    return [
        pygame.Rect(0, 590, 960, 50),
        pygame.Rect(180, 500, 160, 20),
        pygame.Rect(400, 420, 160, 20),
        pygame.Rect(650, 340, 180, 20),
        pygame.Rect(380, 260, 160, 20),
        pygame.Rect(120, 180, 180, 20),
    ]
