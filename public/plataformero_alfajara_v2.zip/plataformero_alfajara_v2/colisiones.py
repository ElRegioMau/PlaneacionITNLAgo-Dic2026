def mover_con_colisiones(jugador, plataformas):
    jugador.x += jugador.velocidad_x
    jugador.rect.x = round(jugador.x)
    for plataforma in plataformas:
        if jugador.rect.colliderect(plataforma):
            if jugador.velocidad_x > 0:
                jugador.rect.right = plataforma.left
            elif jugador.velocidad_x < 0:
                jugador.rect.left = plataforma.right
            jugador.x = float(jugador.rect.x)

    jugador.y += jugador.velocidad_y
    jugador.rect.y = round(jugador.y)
    jugador.en_suelo = False
    for plataforma in plataformas:
        if jugador.rect.colliderect(plataforma):
            if jugador.velocidad_y > 0:
                jugador.rect.bottom = plataforma.top
                jugador.en_suelo = True
            elif jugador.velocidad_y < 0:
                jugador.rect.top = plataforma.bottom
            jugador.y = float(jugador.rect.y)
            jugador.velocidad_y = 0
