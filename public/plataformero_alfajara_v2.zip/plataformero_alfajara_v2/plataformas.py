from pathlib import Path
import pygame


class DibujadorPlataformas:
    """Dibuja las plataformas; los Rect del nivel conservan sus colisiones."""

    def __init__(self):
        ruta = Path(__file__).resolve().parent / "assets" / "plataforma.png"
        self.imagen = None
        self.cache = {}
        if ruta.is_file():
            imagen = pygame.image.load(str(ruta)).convert_alpha()
            limites = imagen.get_bounding_rect(min_alpha=30)
            if limites.width and limites.height:
                self.imagen = imagen.subsurface(limites).copy()

    def _imagen_escalada(self, ancho, alto):
        medida = (ancho, alto)
        if medida not in self.cache:
            self.cache[medida] = pygame.transform.smoothscale(self.imagen, medida)
        return self.cache[medida]

    def dibujar(self, pantalla, plataformas):
        for rect in plataformas:
            if self.imagen is None:
                pygame.draw.rect(pantalla, (100, 190, 120), rect, border_radius=4)
            elif rect.width > 300:
                # Repite la imagen en el suelo para evitar estirarla demasiado.
                for x in range(rect.left, rect.right, 160):
                    ancho = min(160, rect.right - x)
                    pantalla.blit(self._imagen_escalada(ancho, rect.height), (x, rect.top))
            else:
                pantalla.blit(self._imagen_escalada(rect.width, rect.height), rect.topleft)
