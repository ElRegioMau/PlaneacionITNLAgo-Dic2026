# Plataformero modular con Pygame

Proyecto base para aprender movimiento, gravedad, saltos, colisiones y animación. No necesita imágenes para iniciar: utiliza un fondo de color y un rectángulo como jugador mientras no se agreguen los recursos.

## Instalación y ejecución

1. Descomprime el ZIP y abre la carpeta en VS Code.
2. Abre una terminal en esa carpeta.
3. Instala Pygame y ejecuta el juego:

```bash
python -m pip install -r requirements.txt
python main.py
```

Si tu sistema utiliza `python3`, reemplaza `python` por `python3`. También puedes usar un entorno virtual para instalar las dependencias.

## Controles

- **A / D** o **flechas izquierda / derecha**: movimiento.
- **Espacio**, **W** o **flecha arriba**: salto.
- Cierra la ventana para salir.

## Estructura

```text
plataformero_modular/
├── main.py              # Ventana, ciclo principal y fondo
├── player.py            # Movimiento, gravedad, salto y animación
├── colisiones.py        # Colisiones horizontales y verticales
├── nivel.py             # Posición y colisiones de las plataformas
├── plataformas.py       # Dibujo de plataformas con sprite
├── requirements.txt
├── README.md
└── assets/
    ├── fondo.png        # Fondo lateral del cementerio
    ├── plataforma.png   # Sprite de cantera para plataformas y suelo
    └── player/
        ├── idle/        # Quieto
        ├── run/         # Caminando
        ├── jump/        # Subiendo
        └── fall/        # Cayendo
```

## Cambiar el fondo

Coloca tu imagen en `assets/fondo.png`. El juego la ajusta a la ventana de 960 × 640 píxeles; si tiene otra proporción puede verse estirada. Usa una imagen de esa proporción para evitarlo. Sin el archivo se muestra un color sólido.

## Agregar animaciones al jugador

Coloca **imágenes PNG individuales** con transparencia en las carpetas de cada estado, por ejemplo:

```text
assets/player/run/01.png
assets/player/run/02.png
assets/player/run/03.png
```

Los cuadros se reproducen en orden alfabético; numéralos con ceros (`01`, `02`, …, `10`). Usa imágenes mirando hacia la derecha: el juego las voltea automáticamente cuando el jugador va a la izquierda. Puedes poner un solo PNG en una carpeta para mostrar una imagen fija. Si no hay imágenes para un estado, se usa un rectángulo en ese estado.

Las carpetas son `idle` (quieto), `run` (movimiento), `jump` (subida) y `fall` (caída). Los PNG se escalan a 96 × 96 píxeles y se alinean con los pies del jugador. Cambia `TAMANO_SPRITE` y `VELOCIDAD_ANIMACION` en `player.py` para ajustar tamaño y velocidad. Este proyecto espera archivos separados, no una hoja de sprites; corta la hoja en PNG individuales antes de agregarlos. La caja de colisión es independiente de la imagen y se ajusta en `self.rect` dentro de `player.py`.

## Personalizar el nivel y el movimiento

- Cambia los rectángulos de `nivel.py` para colocar plataformas.
- Cambia `velocidad_movimiento`, `fuerza_salto` y `gravedad` en `player.py` para ajustar el movimiento. Una fuerza de salto más negativa produce un salto más alto.
- El juego funciona a 60 cuadros por segundo; las velocidades están expresadas por actualización.

## Identidad visual: Alfajara

El fondo representa el Camposanto del Perpetuo Socorro, inspirado en el proyecto Souls Novo Hispano. Dolores Mendoza aparece con ropa de viaje y un farol. La carpeta `assets` ya contiene el fondo y cuatro cuadros de animación para cada estado. Las imágenes son una adaptación ilustrada para este prototipo.

La hoja original de sprites se entrega por separado; los PNG de `assets/player` ya están divididos y son los que carga el juego. Para sustituirlos, conserva los nombres y las carpetas o utiliza los tuyos siguiendo las indicaciones anteriores.

## Plataformas de cantera

Las plataformas se dibujan con `assets/plataforma.png` y mantienen las colisiones rectangulares de `nivel.py`. `plataformas.py` recorta el margen transparente al cargar la imagen, la adapta al tamaño de cada plataforma y la repite en el suelo. Puedes sustituirla por otro PNG transparente con una superficie superior horizontal. Si falta el archivo, se dibujan rectángulos de color.

El fondo incluido muestra el camposanto desde un costado, con montañas lejanas y detalles discretos para que el personaje destaque. Puedes reemplazar `assets/fondo.png` por otra imagen.

Dolores se dibuja con un contorno claro discreto para distinguirla del fondo. Puedes ajustar su tamaño con `TAMANO_SPRITE` en `player.py`.
