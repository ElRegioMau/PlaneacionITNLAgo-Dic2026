from pathlib import Path
import sys
import pygame

# 1. Inicializar Pygame
pygame.init()

# Configuración de la ventana y el reloj
ANCHO, ALTO = 800, 600
pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Imagen de Fondo y Personaje - Pygame")
reloj = pygame.time.Clock()
FPS = 60

# Ruta base del script (evita errores al ejecutar desde otra carpeta o terminal)
BASE_DIR = Path(__file__).resolve().parent
ASSETS_DIR = BASE_DIR / "assets"

# 2. Cargar imagen de fondo y ajustarla al tamaño de la ventana
# .convert() optimiza la imagen para dibujarse más rápido en pantalla
fondo_original = pygame.image.load(ASSETS_DIR / "fondo.jpg").convert()
fondo = pygame.transform.scale(fondo_original, (ANCHO, ALTO))

# 3. Cargar imagen del personaje y escalarla a un tamaño cómodo
# .convert_alpha() conserva la transparencia (canal alfa) de imágenes PNG
personaje_original = pygame.image.load(ASSETS_DIR / "personaje.png").convert_alpha()
ANCHO_PJ, ALTO_PJ = 64, 64
personaje_img = pygame.transform.scale(personaje_original, (ANCHO_PJ, ALTO_PJ))

# Rectángulo que controla posición y límites del personaje
personaje_rect = personaje_img.get_rect(center=(ANCHO // 2, ALTO // 2))
velocidad = 5

# 4. Ciclo principal del juego (Game Loop)
ejecutando = True
while ejecutando:
    # A) Procesar eventos
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            ejecutando = False

    # B) Actualizar estado (movimiento con flechas o WASD)
    teclas = pygame.key.get_pressed()
    if teclas[pygame.K_LEFT] or teclas[pygame.K_a]:
        personaje_rect.x -= velocidad
    if teclas[pygame.K_RIGHT] or teclas[pygame.K_d]:
        personaje_rect.x += velocidad
    if teclas[pygame.K_UP] or teclas[pygame.K_w]:
        personaje_rect.y -= velocidad
    if teclas[pygame.K_DOWN] or teclas[pygame.K_s]:
        personaje_rect.y += velocidad

    # Limitar el personaje dentro de los bordes de la ventana
    if personaje_rect.left < 0:
        personaje_rect.left = 0
    if personaje_rect.right > ANCHO:
        personaje_rect.right = ANCHO
    if personaje_rect.top < 0:
        personaje_rect.top = 0
    if personaje_rect.bottom > ALTO:
        personaje_rect.bottom = ALTO

    # C) Renderizar (primero el fondo, luego el personaje encima)
    pantalla.blit(fondo, (0, 0))
    pantalla.blit(personaje_img, personaje_rect)

    pygame.display.flip()
    reloj.tick(FPS)

# 5. Finalizar limpiamente
pygame.quit()
sys.exit()