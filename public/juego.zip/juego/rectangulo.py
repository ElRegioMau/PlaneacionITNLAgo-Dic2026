import pygame
import sys

# 1. Inicializar Pygame
pygame.init()

# Configuración de la ventana y el reloj
ANCHO=1000 
ALTO = 800
pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Rectángulo Móvil")
reloj = pygame.time.Clock()
FPS = 120

# Colores (formato RGB)
COLOR_FONDO = (30, 30, 46)
COLOR_JUGADOR = (137, 180, 250)

# Propiedades del "jugador" (un rectángulo: x, y, ancho, alto)
jugador = pygame.Rect(ANCHO // 2 - 25, ALTO // 2 - 25, 50, 50)
velocidad = 5

# 2. Ciclo principal del juego (Game Loop)
ejecutando = True
while ejecutando:
    # A) Procesar eventos (teclado, ratón, cerrar ventana)
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            ejecutando = False

    # B) Actualizar estado (lectura continua de teclas y movimiento)
    teclas = pygame.key.get_pressed()
    if teclas[pygame.K_LEFT] or teclas[pygame.K_a]:
        jugador.x -= velocidad
    if teclas[pygame.K_RIGHT] or teclas[pygame.K_d]:
        jugador.x += velocidad
    if teclas[pygame.K_UP] or teclas[pygame.K_w]:
        jugador.y -= velocidad
    if teclas[pygame.K_DOWN] or teclas[pygame.K_s]:
        jugador.y += velocidad

    # Limitar el movimiento dentro de los bordes de la ventana
    if jugador.left < 0:
        jugador.left = 0
    if jugador.right > ANCHO:
        jugador.right = ANCHO
    if jugador.top < 0:
        jugador.top = 0
    if jugador.bottom > ALTO:
        jugador.bottom = ALTO

    # C) Renderizar (dibujar en pantalla)
    pantalla.fill(COLOR_FONDO)
    pygame.draw.rect(pantalla, COLOR_JUGADOR, jugador)

    # Actualizar el contenido visible y mantener los FPS
    pygame.display.flip()
    reloj.tick(FPS)

# 3. Finalizar limpiamente
pygame.quit()
sys.exit()